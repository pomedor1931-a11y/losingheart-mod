Losing Heart (Fabric 1.21.4, Java 21)
Сборка: открой папку в IntelliJ IDEA как Gradle-проект -> задача build.
Готовый jar: build/libs/losingheart-1.0.0.jar -> положи в mods вместе с Fabric API.
